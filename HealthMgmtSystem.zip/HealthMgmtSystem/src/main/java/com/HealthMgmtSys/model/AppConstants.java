package com.HealthMgmtSys.model;
/**
 *
 * @author kushalbhattarai
 * student ID:12198946
 */
import java.util.HashMap;
import java.util.Map;

public class AppConstants {

    public static Map<String, String> appConstMap = new HashMap<>();
}
